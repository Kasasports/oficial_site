<?php
// Silence is golden. And we agree :)
